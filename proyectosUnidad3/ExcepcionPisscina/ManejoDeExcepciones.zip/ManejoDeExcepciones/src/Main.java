public class Main {
    public static void main(String[] args) {

        PruebasExcepcion pruebas = new PruebasExcepcion();

        pruebas.sacarExcepcion("sI");

        PruebasExcepcion.divisiones();

        //pruebas.divisiones();

    }
}