import java.util.ArrayList;
import java.util.Scanner;

public class CRUDMain {

    private int dni;
    private ArrayList<Persona> personas = new ArrayList<Persona>();

    public void menu() {
        StringBuffer sf = new StringBuffer();

        System.out.println(
                sf.append("MENU PRINCIPAL \n").append("1.- Agregar Estudiante \n").append("2.- Agregar Empleado \n")
                        .append("3.- Agregar Comision \n").append("4.- Buscar \n").append("5.- Terminar programa \n"));
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    boolean encontrar = false;

    public void buscarPersona(Scanner scan) {

        for (Persona persona : this.personas) {
            if (persona.getDni() == getDni()) {
                System.out.println("La persona buscada tiene los siguientes datos");
                StringBuffer sf = new StringBuffer();

                sf
                        .append("Nombre: " + persona.getNombre() + "\n")
                        .append("Matricula: " + persona.getDni() + "\n")
                        .append("Fecha de nacimiento: " + persona.getFechaNacimiento() + "\n");

                if (persona instanceof Estudiante) {
                    encontrar = true;

                    boolean salir = false;
                    int calif = 0, opc = 0;

                    System.out.println("Agrega tu calificación: ");
                    calif = scan.nextInt();
                    ((Estudiante) persona).nuevaCalificacion(calif);

                    StringBuffer sf2 = new StringBuffer();

                    sf2.append("MENÚ PARA Estudiantes \n")
                            .append("1.- Agregar Calificacion \n")
                            .append("2.- Mostrar Promedio")
                            .append("0.- Ir al menú principal");

                    do {
                        System.out.println(sf2);

                        switch (opc) {
                            case 1:
                                System.out.println("Agrega tu calificación: ");
                                calif = scan.nextInt();
                                ((Comision) persona).vender(calif);
                                break;

                            case 2:
                                sf.append("Sueldo: " + ((Comision) persona).getSueldo());
                                System.out.println(sf);
                                break;

                            default:
                                salir = true;
                                break;
                        }

                    } while (salir != true);

                    sf.append("Promedio: " + ((Estudiante) persona).getPuntuacionTotal());
                } else if (persona instanceof Comision) {

                    encontrar = true;

                    boolean salir = false;

                    int vta = 0, opc = 0;

                    StringBuffer sf2 = new StringBuffer();

                    sf2.append("MENÚ PARA COMISIONES \n")
                            .append("1.- Agregar venta \n")
                            .append("2.- Mostrar Sueldo")
                            .append("0.- Ir al menú principal");

                    do {

                        System.out.println(sf2);

                        switch (opc) {
                            case 1:
                                System.out.println("Agrega tu calificación: ");
                                vta = scan.nextInt();
                                ((Comision) persona).vender(vta);
                                break;

                            case 2:
                                sf.append("Sueldo: " + ((Comision) persona).getSueldo());
                                System.out.println(sf);
                                break;

                            default:
                                salir = true;
                                break;
                        }

                    } while (salir != true);

                } else if (persona instanceof Empleado) {
                    encontrar = true;
                    sf.append("Sueldo: " + ((Empleado) persona).getSueldoBase());
                }
                System.out.println(sf);
                if (encontrar) {
                    break;
                }

            } else {
                System.out.println("ESTA PERSONA NO EXISTE EN ESTE SISTEMA");
                break;
            }
        }
    }

    public void createPerson(Persona person) {
        this.personas.add(person);
    }

}
